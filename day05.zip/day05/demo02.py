# 2.判断某年某月有多少天
#         输入年,月
#         输出 本月有多少天, 合理选择分支语句完成任务.
#         例如 输入 2019年 8月
#             输出 2019年8月有31天

year = int(input('请输入年份'))
month = int(input('请输入月份'))

if month == 1 or month == 3 or month == 5 or month == 7 or month == 8 \
        or month == 10 or month == 12:
    print(year, '年', month, '月有', '31天')

elif month == 4 or month == 6 or month == 9 or month == 11:
    print(year, '年', month, '月有', '30天')

elif month == 2 and year % 4 == 0 and year % 100 != 0 or year % 400 == 0:
    print(year, '年', month, '月有', '29天')
else:
    print(year, '年', month, '月有', '28天')





