# 1.判断闰年:
# 用户输入年份year, 判断是否为闰年.
# 能被4整除但不能被100整除, 或者能被400整除, 就是闰年

year = int(input('请输入一个年份'))

if year % 4 == 0 and year % 100 != 0 or year % 400 == 0:
    print(year, '是闰年')
else:
    print(year, '是平年')