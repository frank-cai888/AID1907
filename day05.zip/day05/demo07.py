# 7. 输入三个数作为三个边,判断是否可以组成三角形.
a = int(input("请输入一个数字"))
b = int(input("请输入一个数字"))
c = int(input("请输入一个数字"))

if a > 0 and b > 0 and c > 0:
    if a + b > c and a + c > b and b + c > a:
        print(a,b,c,'三条边可以组成三角形')
    else:
        print(a,b,c,'三条边不可以组成三角形')
else:
    print(a,b,c,'三条边不可以组成三角形')
