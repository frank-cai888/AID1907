# # 输入三个数字, 用if嵌套语句 来判断 最大值 和最小值.
# x = int(input("请输入一个数字"))
# y = int(input("请输入一个数字"))
# z = int(input("请输入一个数字"))
#
# if x < y:
#     if y < z :
#         # x < y < z
#         print(z,'最大')
#         print(x,'最小')
#     elif y > z:
#         print(y, '最大')
#         if x < z:
#             # y > z > x
#             print(x, '最小')
#         elif x > z:
# #             y > x > z
#             print(z, '最小')
# elif x > y:
#     if x < z:
#         # y < x < z
#         print(z, '最大')
#         print(y, '最小')
#     elif x > z:
#         print(x, '最大')
#         # x > z > y
#         if y < z:
#             print(y , '最小')
#         # x > y > z
#         elif y > z:
#             print(z, '最小')
# else:
#     print('这道题太难了, 我不会做.')
#
# 方法二
#
a = int(input("请输入一个数字"))
b = int(input("请输入一个数字"))
c = int(input("请输入一个数字"))

max = a
if b > a:
    if c > b:
        max = c
    else:
        max = b
# b < a
else:
    if a < c:
        max = c
print('最大值:', max)

# 方法三
# a = int(input("请输入一个数字"))
# b = int(input("请输入一个数字"))
# c = int(input("请输入一个数字"))
#
# print(max(a, b, c))
# print(min(a, b, c))
