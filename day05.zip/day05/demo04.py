# 4.输入一个时间 小时 分钟 秒,
#   输出该时间经过5分30秒之后的时间是多少.

hour = int(input("请输入小时"))
minute = int(input("请输入分钟"))
second = int(input("请输入秒"))

minute = minute + 5
second += 30
if second >= 60:
    second -= 60
    minute += 1
if minute >= 60:
    minute -= 60
    hour += 1
if hour == 24:
    hour = 0
print(hour, minute, second)





















