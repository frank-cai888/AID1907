# 5.判断学生成绩等级
# 85分以上
# 优秀70 - 85
# 良好60 - 70
# 及格60分以下不及格

s = float(input("请输入学生成绩"))

if s >= 60:
    if s >= 70:
        if s >= 85:
            print('优秀')
        else:
            print('良好')
    else:
        print('及格')
else:
    print('不及格')



















